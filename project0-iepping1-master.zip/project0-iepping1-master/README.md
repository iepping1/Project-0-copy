# Project 0

Web Programming with Python and JavaScript

Just a small site that resembles my final project with a few recipes and ingredients pulled from the spoonacular API randomly.
